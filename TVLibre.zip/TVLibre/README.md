# TV Libre
Reproductor de TV en línea gratuita (listas públicas iptv-org o tu propia lista M3U) y películas/series legales gratis del Internet Archive (dominio público).
Compilar: sube esta carpeta a un repo de GitHub -> pestaña Actions -> "Build APK" -> descarga el artefacto TVLibre-APK.
Uso: toca un canal para verlo, mantén pulsado para agregar a favoritos, "+ Lista" para tu propia URL M3U.
