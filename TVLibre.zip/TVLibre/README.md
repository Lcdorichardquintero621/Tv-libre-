# TV Libre
Reproductor de TV en línea gratuita (listas públicas iptv-org o tu propia lista M3U) y películas/series legales gratis del Internet Archive (dominio público).
Compilar: sube esta carpeta a un repo de GitHub -> pestaña Actions -> "Build APK" -> descarga el artefacto TVLibre-APK.
Uso: cada fila muestra miniatura, país, idioma, categoría y un estado (✓ verde = la fuente responde desde tu teléfono). ☆ = favoritos; ⋮ = agregar a tus listas; "⋮ Listas" = crear/eliminar listas o agregar una URL M3U.
