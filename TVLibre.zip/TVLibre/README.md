# TV Libre
Reproductor de TV en línea gratuita (listas públicas iptv-org o tu propia lista M3U) y películas/series legales gratis del Internet Archive (dominio público).
Compilar: sube esta carpeta a un repo de GitHub -> pestaña Actions -> "Build APK" -> descarga el artefacto TVLibre-APK.
Uso: chips de países arriba (Venezuela, Ecuador, etc.). Toca un canal: se abre el reproductor con la lista debajo para cambiar de canal; toca el video para ver pausa, atrás, canal anterior/siguiente y pantalla completa; girar el teléfono = pantalla completa. ☆ = favoritos; ⋮ = tus listas.
