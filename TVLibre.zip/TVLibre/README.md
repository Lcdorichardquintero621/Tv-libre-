# TV Libre
Reproductor de TV en línea gratuita (listas públicas iptv-org o tu propia lista M3U) y películas/series legales gratis del Internet Archive (dominio público).
Compilar: sube esta carpeta a un repo de GitHub -> pestaña Actions -> "Build APK" -> descarga el artefacto TVLibre-APK.
Uso: cada fila muestra miniatura; toca ☆ para favoritos, ⋮ (o mantén pulsado) para agregar a tus listas; el botón "⋮ Listas" crea/elimina listas o agrega una URL M3U.
