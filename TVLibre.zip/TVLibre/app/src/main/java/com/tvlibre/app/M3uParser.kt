package com.tvlibre.app

data class Channel(val name: String, val group: String, val url: String)

object M3uParser {
    private val groupRe = Regex("group-title=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                name = line.substringAfterLast(",").trim()
                group = groupRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
            } else if (line.isNotEmpty() && !line.startsWith("#") && name != null) {
                if (line.startsWith("http")) {
                    out.add(Channel(name.ifEmpty { "Sin nombre" }, group.ifEmpty { "General" }, line))
                }
                name = null
                group = ""
            }
        }
        return out
    }
}
