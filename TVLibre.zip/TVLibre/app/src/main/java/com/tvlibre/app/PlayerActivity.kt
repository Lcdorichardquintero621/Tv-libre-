package com.tvlibre.app

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

/** Lista que se está viendo (por ejemplo Venezuela) para pasar de canal en canal. */
object Zap {
    var items: List<Channel> = emptyList()
    var index = 0
    var label = ""
}

fun infoLine(ch: Channel): String {
    val parts = ArrayList<String>()
    if (ch.country.isNotEmpty()) parts.add((Info.flag(ch.country) + " " + Info.countryName(ch.country)).trim())
    if (ch.lang.isNotEmpty()) parts.add(ch.lang)
    if (ch.group.isNotEmpty()) parts.add(ch.group)
    return parts.joinToString(" · ")
}

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var container: FrameLayout
    private lateinit var list: RecyclerView
    private lateinit var header: TextView
    private lateinit var titleView: TextView
    private lateinit var fsBtn: ImageButton
    private lateinit var timeRow: View
    private lateinit var adapter: ZapAdapter
    private val handler = Handler(Looper.getMainLooper())

    private var items: List<Channel> = emptyList()
    private var index = 0
    private var fullscreen = false
    private var loadId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        items = Zap.items
        if (items.isEmpty()) { finish(); return }
        index = Zap.index.coerceIn(0, items.size - 1)

        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = findViewById(R.id.playerView)
        container = findViewById(R.id.playerContainer)
        list = findViewById(R.id.zapList)
        header = findViewById(R.id.listHeader)
        titleView = view.findViewById(R.id.player_title)
        fsBtn = view.findViewById(R.id.btn_fullscreen)
        timeRow = view.findViewById(R.id.time_row)

        view.findViewById<View>(R.id.btn_back).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        view.findViewById<View>(R.id.btn_prev_channel).setOnClickListener { step(-1) }
        view.findViewById<View>(R.id.btn_next_channel).setOnClickListener { step(1) }
        fsBtn.setOnClickListener { toggleFullscreen() }

        adapter = ZapAdapter(items) { playIndex(it) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        header.text = (if (Zap.label.isEmpty()) "Canales" else Zap.label) + " · " + items.size + " para elegir"

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fullscreen) toggleFullscreen() else finish()
            }
        })
        applyMode()
    }

    override fun onStart() {
        super.onStart()
        if (items.isEmpty()) return
        player = ExoPlayer.Builder(this).build().also { p ->
            view.player = p
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Toast.makeText(
                        this@PlayerActivity,
                        "No se pudo reproducir este canal (puede estar caído o bloqueado)",
                        Toast.LENGTH_LONG
                    ).show()
                }
                override fun onPlaybackStateChanged(playbackState: Int) { updateTimeRow() }
            })
        }
        playIndex(index)
    }

    override fun onStop() {
        super.onStop()
        loadId++
        view.player = null
        player?.release()
        player = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyMode()
    }

    // ---------- Cambiar de canal ----------

    private fun step(d: Int) {
        if (items.isEmpty()) return
        playIndex((index + d + items.size) % items.size)
    }

    private fun playIndex(i: Int) {
        index = i
        Zap.index = i
        val ch = items[i]
        titleView.text = ch.name
        adapter.setCurrent(i)
        list.smoothScrollToPosition(i)
        val id = ++loadId
        if (ch.url.startsWith("ia://")) {
            Toast.makeText(this, "Preparando película…", Toast.LENGTH_SHORT).show()
            Thread {
                val real = try { Net.resolveArchive(ch.url.removePrefix("ia://")) } catch (e: Exception) { null }
                runOnUiThread {
                    if (id != loadId) return@runOnUiThread
                    if (real == null) {
                        Toast.makeText(this, "No se encontró un video reproducible", Toast.LENGTH_LONG).show()
                    } else {
                        start(real)
                    }
                }
            }.start()
        } else {
            start(ch.url)
        }
    }

    private fun start(url: String) {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(url).apply {
            if (url.contains("m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
        view.showController()
    }

    private fun updateTimeRow() {
        val p = player ?: return
        val live = p.isCurrentMediaItemLive || p.duration == C.TIME_UNSET
        timeRow.visibility = if (live) View.INVISIBLE else View.VISIBLE
    }

    // ---------- Pantalla completa / girar el teléfono ----------

    private fun toggleFullscreen() {
        if (fullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            handler.postDelayed({ requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }, 2000)
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    /** Horizontal = pantalla completa (sin lista ni barras); vertical = video arriba y canales abajo. */
    private fun applyMode() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        fullscreen = land
        list.visibility = if (land) View.GONE else View.VISIBLE
        header.visibility = if (land) View.GONE else View.VISIBLE
        val lp = container.layoutParams
        lp.height = if (land) ViewGroup.LayoutParams.MATCH_PARENT
                    else (resources.displayMetrics.widthPixels * 9f / 16f).toInt()
        container.layoutParams = lp
        fsBtn.setImageResource(if (land) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)

        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        if (land) {
            ctrl.hide(WindowInsetsCompat.Type.systemBars())
            ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            ctrl.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}

/** Lista compacta de canales debajo del video. */
class ZapAdapter(
    private val items: List<Channel>,
    private val onPick: (Int) -> Unit
) : RecyclerView.Adapter<ZapAdapter.VH>() {
    private var current = -1
    private val main = Handler(Looper.getMainLooper())

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val now: TextView = v.findViewById(R.id.now)
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val info: TextView = v.findViewById(R.id.info)
        val status: TextView = v.findViewById(R.id.status)
    }

    fun setCurrent(i: Int) {
        val old = current
        current = i
        if (old >= 0) notifyItemChanged(old, "now")
        notifyItemChanged(i, "now")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_zap, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.name.text = ch.name
        h.info.text = infoLine(ch)
        if (ch.logo.isEmpty()) {
            Glide.with(h.thumb).clear(h.thumb)
            h.thumb.setImageResource(R.drawable.ic_placeholder)
        } else {
            Glide.with(h.thumb).load(ch.logo)
                .placeholder(R.drawable.ic_placeholder)
                .error(R.drawable.ic_placeholder)
                .into(h.thumb)
        }
        bindDynamic(h, position)
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onPick(p)
        }
    }

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) bindDynamic(h, position)
        else super.onBindViewHolder(h, position, payloads)
    }

    private fun bindDynamic(h: VH, position: Int) {
        val ch = items[position]
        h.now.visibility = if (position == current) View.VISIBLE else View.INVISIBLE
        var st = StatusChecker.status(ch.url)
        if (st == -1) {
            StatusChecker.request(ch) { main.post { notifyItemChanged(position, "status") } }
            st = 0
        }
        when (st) {
            1 -> { h.status.text = "✓"; h.status.setBackgroundResource(R.drawable.bg_ok) }
            2 -> { h.status.text = "✕"; h.status.setBackgroundResource(R.drawable.bg_fail) }
            else -> { h.status.text = "…"; h.status.setBackgroundResource(R.drawable.bg_wait) }
        }
    }
}
