package com.tvlibre.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private val FAV = "★ Favoritos"
    private val base = "https://iptv-org.github.io/iptv"
    private val sources = LinkedHashMap<String, String>()
    private val listLabels = LinkedHashMap<String, String>() // etiqueta del selector -> nombre de lista
    private var labels: List<String> = emptyList()
    private var currentLabel = ""
    private var all: List<Channel> = emptyList()
    private var requestId = 0

    private lateinit var prefs: SharedPreferences
    private lateinit var store: ListStore
    private lateinit var spinner: Spinner
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("tv", Context.MODE_PRIVATE)
        store = ListStore(prefs, FAV)

        // Películas y series gratis y legales (Internet Archive, dominio público)
        sources["🎬 Películas clásicas"] = "ia:collection:feature_films AND mediatype:movies"
        sources["🎬 Películas en español"] = "ia:collection:feature_films AND mediatype:movies AND (language:Spanish OR language:spa)"
        sources["🎬 Ciencia ficción y terror"] = "ia:collection:SciFi_Horror AND mediatype:movies"
        sources["🎬 Cine mudo"] = "ia:collection:silent_films AND mediatype:movies"
        sources["📺 TV clásica"] = "ia:collection:classic_tv AND mediatype:movies"
        // TV en línea gratis (listas públicas iptv-org)
        sources["Perú"] = "$base/countries/pe.m3u"
        sources["Español (todos)"] = "$base/languages/spa.m3u"
        sources["México"] = "$base/countries/mx.m3u"
        sources["España"] = "$base/countries/es.m3u"
        sources["Argentina"] = "$base/countries/ar.m3u"
        sources["Colombia"] = "$base/countries/co.m3u"
        sources["Chile"] = "$base/countries/cl.m3u"
        sources["Estados Unidos"] = "$base/countries/us.m3u"
        prefs.getString("custom", null)?.let { sources["Mi lista M3U"] = it }

        spinner = findViewById(R.id.spinner)
        search = findViewById(R.id.search)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)

        adapter = ChannelAdapter(
            onClick = { open(it) },
            onFav = { toggleFav(it) },
            onMenu = { showListsDialog(it) },
            isFav = { store.contains(FAV, it) }
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })
        findViewById<Button>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        setupSpinner(null)
    }

    // ---------- Selector de fuentes y listas ----------

    private fun setupSpinner(select: String?) {
        listLabels.clear()
        val l = ArrayList<String>()
        for (n in store.names()) {
            val label = if (n == FAV) FAV else "📁 $n"
            listLabels[label] = n
            l.add(label)
        }
        l.addAll(sources.keys)
        labels = l
        spinner.onItemSelectedListener = null
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, l)
        val idx = l.indexOf(select ?: currentLabel)
        spinner.setSelection(if (idx < 0) 0 else idx)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val label = labels[pos]
                if (label == currentLabel) return
                currentLabel = label
                load(label)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun load(label: String) {
        val id = ++requestId
        val listName = listLabels[label]
        if (listName != null) {
            progress.visibility = View.GONE
            all = store.get(listName)
            applyFilter()
            return
        }
        val url = sources[label] ?: return
        progress.visibility = View.VISIBLE
        Thread {
            try {
                val list = if (url.startsWith("ia:")) searchArchive(url.removePrefix("ia:"))
                           else M3uParser.parse(httpGet(url))
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = list
                    applyFilter()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = emptyList()
                    applyFilter()
                    Toast.makeText(this, "No se pudo cargar la lista", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        val list = if (q.isEmpty()) all else all.filter {
            it.name.lowercase().contains(q) || it.group.lowercase().contains(q)
        }
        adapter.submit(list)
        empty.visibility = if (list.isEmpty() && progress.visibility != View.VISIBLE) View.VISIBLE else View.GONE
    }

    private fun refreshView() {
        val ln = listLabels[currentLabel]
        if (ln != null) {
            all = store.get(ln)
            applyFilter()
        } else {
            adapter.notifyDataSetChanged()
        }
    }

    // ---------- Favoritos y listas personalizadas ----------

    private fun toggleFav(ch: Channel) {
        val msg: String
        if (store.contains(FAV, ch)) {
            store.remove(FAV, ch); msg = "Quitado de $FAV"
        } else {
            store.add(FAV, ch); msg = "Agregado a $FAV"
        }
        store.save()
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        refreshView()
    }

    private fun showListsDialog(ch: Channel) {
        val names = store.names().toTypedArray()
        val checked = BooleanArray(names.size) { store.contains(names[it], ch) }
        fun applyChecks() {
            names.forEachIndexed { i, n -> if (checked[i]) store.add(n, ch) else store.remove(n, ch) }
            store.save()
            refreshView()
        }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Guardar") { _, _ -> applyChecks() }
            .setNeutralButton("Nueva lista") { _, _ ->
                applyChecks()
                askNewList { showListsDialog(ch) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askNewList(onDone: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Nombre de la lista" }
        AlertDialog.Builder(this)
            .setTitle("Nueva lista")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isEmpty() || store.names().contains(n) || n == FAV) {
                    Toast.makeText(this, "Nombre no válido o ya existe", Toast.LENGTH_SHORT).show()
                } else {
                    store.create(n)
                    store.save()
                    setupSpinner(null)
                    onDone(n)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Nueva lista")
            menu.add(0, 2, 1, "Eliminar lista actual")
            menu.add(0, 3, 2, "Agregar lista M3U (URL)")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> askNewList { n -> setupSpinner("📁 $n") }
                    2 -> deleteCurrentList()
                    3 -> askCustom()
                }
                true
            }
            show()
        }
    }

    private fun deleteCurrentList() {
        val ln = listLabels[currentLabel]
        if (ln == null || ln == FAV) {
            Toast.makeText(this, "Elige primero una de tus listas (📁)", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Eliminar \"$ln\"")
            .setMessage("Se borrará la lista y su contenido guardado.")
            .setPositiveButton("Eliminar") { _, _ ->
                store.delete(ln)
                store.save()
                setupSpinner(FAV)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askCustom() {
        val input = EditText(this).apply {
            hint = "https://...lista.m3u"
            setText(prefs.getString("custom", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("URL de lista M3U")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http")) {
                    prefs.edit().putString("custom", u).apply()
                    sources["Mi lista M3U"] = u
                    currentLabel = ""
                    setupSpinner("Mi lista M3U")
                } else {
                    Toast.makeText(this, "URL no válida", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Reproducción y fuentes ----------

    private fun open(ch: Channel) {
        if (ch.url.startsWith("ia://")) {
            Toast.makeText(this, "Preparando película…", Toast.LENGTH_SHORT).show()
            Thread {
                val real = try { resolveArchive(ch.url.removePrefix("ia://")) } catch (e: Exception) { null }
                runOnUiThread {
                    if (real == null) {
                        Toast.makeText(this, "No se encontró un video reproducible", Toast.LENGTH_LONG).show()
                    } else {
                        play(ch.name, real)
                    }
                }
            }.start()
        } else {
            play(ch.name, ch.url)
        }
    }

    private fun play(name: String, url: String) {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("name", name).putExtra("url", url))
    }

    private fun httpGet(u: String): String {
        val conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    private fun searchArchive(q: String): List<Channel> {
        val u = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(q, "UTF-8") +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&sort%5B%5D=downloads+desc&rows=200&output=json"
        val docs = JSONObject(httpGet(u)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Channel>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier")
            if (id.isEmpty()) continue
            val t = d.opt("title")
            val title = (if (t is JSONArray) t.optString(0) else d.optString("title")).ifEmpty { id }
            val year = d.optString("year")
            out.add(Channel(
                title,
                if (year.isEmpty()) "Internet Archive" else year,
                "ia://$id",
                "https://archive.org/services/img/$id"
            ))
        }
        return out
    }

    private fun resolveArchive(id: String): String? {
        val files = JSONObject(httpGet("https://archive.org/metadata/" + Uri.encode(id)))
            .optJSONArray("files") ?: return null
        var fallback: String? = null
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val n = f.optString("name")
            if (!n.endsWith(".mp4", ignoreCase = true)) continue
            if (f.optString("format").contains("h.264", ignoreCase = true)) {
                return "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/")
            }
            if (fallback == null) fallback = n
        }
        return fallback?.let { "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(it, "/") }
    }

    // ---------- Adaptador con miniaturas ----------

    class ChannelAdapter(
        private val onClick: (Channel) -> Unit,
        private val onFav: (Channel) -> Unit,
        private val onMenu: (Channel) -> Unit,
        private val isFav: (Channel) -> Boolean
    ) : RecyclerView.Adapter<ChannelAdapter.VH>() {
        private var items: List<Channel> = emptyList()

        fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.thumb)
            val name: TextView = v.findViewById(R.id.name)
            val group: TextView = v.findViewById(R.id.group)
            val star: TextView = v.findViewById(R.id.star)
            val menu: TextView = v.findViewById(R.id.menu)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val ch = items[position]
            h.name.text = ch.name
            h.group.text = ch.group
            if (ch.logo.isEmpty()) {
                Glide.with(h.thumb).clear(h.thumb)
                h.thumb.setImageResource(R.drawable.ic_placeholder)
            } else {
                Glide.with(h.thumb).load(ch.logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(h.thumb)
            }
            h.star.text = if (isFav(ch)) "★" else "☆"
            h.star.setOnClickListener { onFav(ch) }
            h.menu.setOnClickListener { onMenu(ch) }
            h.itemView.setOnClickListener { onClick(ch) }
            h.itemView.setOnLongClickListener { onMenu(ch); true }
        }
    }
}
