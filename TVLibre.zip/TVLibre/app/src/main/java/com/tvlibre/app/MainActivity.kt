package com.tvlibre.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val FAV = "★ Favoritos"
    private val SEP = "\u0001"
    private val base = "https://iptv-org.github.io/iptv"
    private val sources = LinkedHashMap<String, String>()
    private var all: List<Channel> = emptyList()
    private var requestId = 0

    private lateinit var prefs: SharedPreferences
    private lateinit var spinner: Spinner
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("tv", Context.MODE_PRIVATE)

        sources[FAV] = ""
        // Películas y series gratis y legales (Internet Archive, dominio público)
        sources["🎬 Películas clásicas"] = "ia:collection:feature_films AND mediatype:movies"
        sources["🎬 Películas en español"] = "ia:collection:feature_films AND mediatype:movies AND (language:Spanish OR language:spa)"
        sources["🎬 Ciencia ficción y terror"] = "ia:collection:SciFi_Horror AND mediatype:movies"
        sources["🎬 Cine mudo"] = "ia:collection:silent_films AND mediatype:movies"
        sources["📺 TV clásica"] = "ia:collection:classic_tv AND mediatype:movies"
        sources["Perú"] = "$base/countries/pe.m3u"
        sources["Español (todos)"] = "$base/languages/spa.m3u"
        sources["México"] = "$base/countries/mx.m3u"
        sources["España"] = "$base/countries/es.m3u"
        sources["Argentina"] = "$base/countries/ar.m3u"
        sources["Colombia"] = "$base/countries/co.m3u"
        sources["Chile"] = "$base/countries/cl.m3u"
        sources["Estados Unidos"] = "$base/countries/us.m3u"
        prefs.getString("custom", null)?.let { sources["Mi lista"] = it }

        spinner = findViewById(R.id.spinner)
        search = findViewById(R.id.search)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)

        adapter = ChannelAdapter(
            onClick = { open(it) },
            onLong = { toggleFav(it) },
            isFav = { favorites().any { f -> f.url == it.url } }
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })
        findViewById<Button>(R.id.btnAdd).setOnClickListener { askCustom() }
        setupSpinner(null)
    }

    private fun setupSpinner(select: String?) {
        val names = sources.keys.toList()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                load(names[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        select?.let { spinner.setSelection(names.indexOf(it).coerceAtLeast(0)) }
    }

    private fun load(name: String) {
        val id = ++requestId
        if (name == FAV) {
            all = favorites()
            applyFilter()
            return
        }
        val url = sources[name] ?: return
        progress.visibility = View.VISIBLE
        Thread {
            try {
                val list = if (url.startsWith("ia:")) searchArchive(url.removePrefix("ia:"))
                           else M3uParser.parse(httpGet(url))
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = list
                    applyFilter()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = emptyList()
                    applyFilter()
                    Toast.makeText(this, "No se pudo cargar la lista", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        val list = if (q.isEmpty()) all else all.filter {
            it.name.lowercase().contains(q) || it.group.lowercase().contains(q)
        }
        adapter.submit(list)
        empty.visibility = if (list.isEmpty() && progress.visibility != View.VISIBLE) View.VISIBLE else View.GONE
    }

    private fun open(ch: Channel) {
        if (ch.url.startsWith("ia://")) {
            Toast.makeText(this, "Preparando película…", Toast.LENGTH_SHORT).show()
            Thread {
                val real = try { resolveArchive(ch.url.removePrefix("ia://")) } catch (e: Exception) { null }
                runOnUiThread {
                    if (real == null) {
                        Toast.makeText(this, "No se encontró un video reproducible", Toast.LENGTH_LONG).show()
                    } else {
                        play(ch.name, real)
                    }
                }
            }.start()
        } else {
            play(ch.name, ch.url)
        }
    }

    private fun play(name: String, url: String) {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("name", name).putExtra("url", url))
    }

    private fun httpGet(u: String): String {
        val conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    private fun searchArchive(q: String): List<Channel> {
        val u = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(q, "UTF-8") +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&sort%5B%5D=downloads+desc&rows=200&output=json"
        val docs = JSONObject(httpGet(u)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Channel>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier")
            if (id.isEmpty()) continue
            val t = d.opt("title")
            val title = (if (t is JSONArray) t.optString(0) else d.optString("title")).ifEmpty { id }
            val year = d.optString("year")
            out.add(Channel(title, if (year.isEmpty()) "Internet Archive" else year, "ia://$id"))
        }
        return out
    }

    private fun resolveArchive(id: String): String? {
        val files = JSONObject(httpGet("https://archive.org/metadata/" + Uri.encode(id)))
            .optJSONArray("files") ?: return null
        var fallback: String? = null
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val n = f.optString("name")
            if (!n.endsWith(".mp4", ignoreCase = true)) continue
            if (f.optString("format").contains("h.264", ignoreCase = true)) {
                return "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/")
            }
            if (fallback == null) fallback = n
        }
        return fallback?.let { "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(it, "/") }
    }

    private fun favorites(): List<Channel> =
        (prefs.getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull {
            val p = it.split(SEP)
            if (p.size == 3) Channel(p[0], p[1], p[2]) else null
        }.sortedBy { it.name.lowercase() }

    private fun toggleFav(ch: Channel) {
        val set = HashSet(prefs.getStringSet("favs", emptySet()) ?: emptySet())
        val key = listOf(ch.name, ch.group, ch.url).joinToString(SEP)
        val msg: String
        if (set.remove(key)) {
            msg = "Quitado de favoritos"
        } else {
            set.add(key); msg = "Agregado a favoritos"
        }
        prefs.edit().putStringSet("favs", set).apply()
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        if (spinner.selectedItem == FAV) { all = favorites(); applyFilter() } else adapter.notifyDataSetChanged()
    }

    private fun askCustom() {
        val input = EditText(this).apply {
            hint = "https://...lista.m3u"
            setText(prefs.getString("custom", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("URL de lista M3U")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http")) {
                    prefs.edit().putString("custom", u).apply()
                    sources["Mi lista"] = u
                    setupSpinner("Mi lista")
                } else {
                    Toast.makeText(this, "URL no válida", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    class ChannelAdapter(
        private val onClick: (Channel) -> Unit,
        private val onLong: (Channel) -> Unit,
        private val isFav: (Channel) -> Boolean
    ) : RecyclerView.Adapter<ChannelAdapter.VH>() {
        private var items: List<Channel> = emptyList()

        fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.name)
            val group: TextView = v.findViewById(R.id.group)
            val star: TextView = v.findViewById(R.id.star)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val ch = items[position]
            h.name.text = ch.name
            h.group.text = ch.group
            h.star.visibility = if (isFav(ch)) View.VISIBLE else View.GONE
            h.itemView.setOnClickListener { onClick(ch) }
            h.itemView.setOnLongClickListener { onLong(ch); true }
        }
    }
}
