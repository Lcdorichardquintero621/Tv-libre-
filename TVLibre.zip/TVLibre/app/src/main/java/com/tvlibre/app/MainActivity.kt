package com.tvlibre.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {

    private val FAV = "★ Favoritos"
    private val DEFAULT = "Español (todos)"
    private val base = "https://iptv-org.github.io/iptv"
    private val sources = LinkedHashMap<String, String>()
    private val listLabels = LinkedHashMap<String, String>() // etiqueta del chip -> nombre de lista
    private var currentLabel = ""
    private var all: List<Channel> = emptyList()
    private var requestId = 0

    private lateinit var prefs: SharedPreferences
    private lateinit var store: ListStore
    private lateinit var chips: ChipGroup
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var countText: TextView
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("tv", Context.MODE_PRIVATE)
        store = ListStore(prefs, FAV)

        // TV en línea gratis (listas públicas iptv-org)
        sources[DEFAULT] = "$base/languages/spa.m3u"
        sources["Perú"] = "$base/countries/pe.m3u"
        sources["México"] = "$base/countries/mx.m3u"
        sources["España"] = "$base/countries/es.m3u"
        sources["Argentina"] = "$base/countries/ar.m3u"
        sources["Colombia"] = "$base/countries/co.m3u"
        sources["Chile"] = "$base/countries/cl.m3u"
        sources["Estados Unidos"] = "$base/countries/us.m3u"
        // Películas y series gratis y legales (Internet Archive, dominio público)
        sources["🎬 Películas clásicas"] = "ia:collection:feature_films AND mediatype:movies"
        sources["🎬 Películas en español"] = "ia:collection:feature_films AND mediatype:movies AND (language:Spanish OR language:spa)"
        sources["🎬 Ciencia ficción y terror"] = "ia:collection:SciFi_Horror AND mediatype:movies"
        sources["🎬 Cine mudo"] = "ia:collection:silent_films AND mediatype:movies"
        sources["📺 TV clásica"] = "ia:collection:classic_tv AND mediatype:movies"
        prefs.getString("custom", null)?.let { sources["Mi lista M3U"] = it }

        chips = findViewById(R.id.chips)
        search = findViewById(R.id.search)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)
        countText = findViewById(R.id.count)

        adapter = ChannelAdapter(
            onClick = { open(it) },
            onFav = { toggleFav(it) },
            onMenu = { showListsDialog(it) },
            isFav = { store.contains(FAV, it) }
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        setupChips(null)
    }

    // ---------- Categorías (chips) y listas ----------

    private fun setupChips(select: String?) {
        listLabels.clear()
        val l = ArrayList<String>()
        for (n in store.names()) {
            val label = if (n == FAV) FAV else "📁 $n"
            listLabels[label] = n
            l.add(label)
        }
        l.addAll(sources.keys)
        val wanted = select ?: currentLabel
        val target = if (wanted in l) wanted else DEFAULT

        chips.removeAllViews()
        for (label in l) {
            val chip = layoutInflater.inflate(R.layout.chip_filter, chips, false) as Chip
            chip.id = View.generateViewId()
            chip.text = label
            chip.setOnClickListener {
                if (label != currentLabel) {
                    currentLabel = label
                    load(label)
                }
            }
            chips.addView(chip)
            if (label == target) chip.isChecked = true
        }
        if (target != currentLabel) {
            currentLabel = target
            load(target)
        }
    }

    private fun load(label: String) {
        val id = ++requestId
        val listName = listLabels[label]
        if (listName != null) {
            progress.visibility = View.GONE
            all = store.get(listName)
            applyFilter()
            return
        }
        val url = sources[label] ?: return
        val defaultLang = if (label == DEFAULT) "Español" else ""
        progress.visibility = View.VISIBLE
        Thread {
            try {
                val list = if (url.startsWith("ia:")) Net.searchArchive(url.removePrefix("ia:"))
                           else M3uParser.parse(Net.httpGet(url), defaultLang)
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = list
                    applyFilter()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = emptyList()
                    applyFilter()
                    Toast.makeText(this, "No se pudo cargar la lista", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        val list = if (q.isEmpty()) all else all.filter {
            it.name.lowercase().contains(q) || it.group.lowercase().contains(q) ||
                Info.countryName(it.country).lowercase().contains(q) || it.lang.lowercase().contains(q)
        }
        adapter.submit(list)
        countText.text = "${list.size} resultados"
        empty.visibility = if (list.isEmpty() && progress.visibility != View.VISIBLE) View.VISIBLE else View.GONE
    }

    private fun refreshView() {
        val ln = listLabels[currentLabel]
        if (ln != null) {
            all = store.get(ln)
            applyFilter()
        } else {
            adapter.notifyDataSetChanged()
        }
    }

    // ---------- Favoritos y listas personalizadas ----------

    private fun toggleFav(ch: Channel) {
        val msg: String
        if (store.contains(FAV, ch)) {
            store.remove(FAV, ch); msg = "Quitado de $FAV"
        } else {
            store.add(FAV, ch); msg = "Agregado a $FAV"
        }
        store.save()
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        refreshView()
    }

    private fun showListsDialog(ch: Channel) {
        val names = store.names().toTypedArray()
        val checked = BooleanArray(names.size) { store.contains(names[it], ch) }
        fun applyChecks() {
            names.forEachIndexed { i, n -> if (checked[i]) store.add(n, ch) else store.remove(n, ch) }
            store.save()
            refreshView()
        }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Guardar") { _, _ -> applyChecks() }
            .setNeutralButton("Nueva lista") { _, _ ->
                applyChecks()
                askNewList { showListsDialog(ch) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askNewList(onDone: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Nombre de la lista" }
        AlertDialog.Builder(this)
            .setTitle("Nueva lista")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isEmpty() || store.names().contains(n) || n == FAV) {
                    Toast.makeText(this, "Nombre no válido o ya existe", Toast.LENGTH_SHORT).show()
                } else {
                    store.create(n)
                    store.save()
                    setupChips(null)
                    onDone(n)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Nueva lista")
            menu.add(0, 2, 1, "Eliminar lista actual")
            menu.add(0, 3, 2, "Agregar lista M3U (URL)")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> askNewList { n -> setupChips("📁 $n") }
                    2 -> deleteCurrentList()
                    3 -> askCustom()
                }
                true
            }
            show()
        }
    }

    private fun deleteCurrentList() {
        val ln = listLabels[currentLabel]
        if (ln == null || ln == FAV) {
            Toast.makeText(this, "Elige primero una de tus listas (📁)", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Eliminar \"$ln\"")
            .setMessage("Se borrará la lista y su contenido guardado.")
            .setPositiveButton("Eliminar") { _, _ ->
                store.delete(ln)
                store.save()
                setupChips(FAV)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askCustom() {
        val input = EditText(this).apply {
            hint = "https://...lista.m3u"
            setText(prefs.getString("custom", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("URL de lista M3U")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http")) {
                    prefs.edit().putString("custom", u).apply()
                    sources["Mi lista M3U"] = u
                    currentLabel = ""
                    setupChips("Mi lista M3U")
                } else {
                    Toast.makeText(this, "URL no válida", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Reproducción ----------

    private fun open(ch: Channel) {
        if (ch.url.startsWith("ia://")) {
            Toast.makeText(this, "Preparando película…", Toast.LENGTH_SHORT).show()
            Thread {
                val real = try { Net.resolveArchive(ch.url.removePrefix("ia://")) } catch (e: Exception) { null }
                runOnUiThread {
                    if (real == null) {
                        Toast.makeText(this, "No se encontró un video reproducible", Toast.LENGTH_LONG).show()
                    } else {
                        play(ch.name, real)
                    }
                }
            }.start()
        } else {
            play(ch.name, ch.url)
        }
    }

    private fun play(name: String, url: String) {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("name", name).putExtra("url", url))
    }

    // ---------- Adaptador: miniatura, país, idioma y estado ----------

    class ChannelAdapter(
        private val onClick: (Channel) -> Unit,
        private val onFav: (Channel) -> Unit,
        private val onMenu: (Channel) -> Unit,
        private val isFav: (Channel) -> Boolean
    ) : RecyclerView.Adapter<ChannelAdapter.VH>() {
        private var items: List<Channel> = emptyList()
        private val main = Handler(Looper.getMainLooper())

        fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.thumb)
            val name: TextView = v.findViewById(R.id.name)
            val info: TextView = v.findViewById(R.id.info)
            val group: TextView = v.findViewById(R.id.group)
            val status: TextView = v.findViewById(R.id.status)
            val star: TextView = v.findViewById(R.id.star)
            val menu: TextView = v.findViewById(R.id.menu)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val ch = items[position]
            h.name.text = ch.name
            h.group.text = ch.group

            val parts = ArrayList<String>()
            if (ch.country.isNotEmpty()) {
                parts.add((Info.flag(ch.country) + " " + Info.countryName(ch.country)).trim())
            }
            if (ch.lang.isNotEmpty()) parts.add(ch.lang)
            h.info.text = parts.joinToString(" · ")
            h.info.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE

            if (ch.logo.isEmpty()) {
                Glide.with(h.thumb).clear(h.thumb)
                h.thumb.setImageResource(R.drawable.ic_placeholder)
            } else {
                Glide.with(h.thumb).load(ch.logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(h.thumb)
            }

            bindStatus(h, ch)
            h.star.text = if (isFav(ch)) "★" else "☆"
            h.star.setOnClickListener { onFav(ch) }
            h.menu.setOnClickListener { onMenu(ch) }
            h.itemView.setOnClickListener { onClick(ch) }
            h.itemView.setOnLongClickListener { onMenu(ch); true }
        }

        override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
            if (payloads.isNotEmpty()) bindStatus(h, items[position])
            else super.onBindViewHolder(h, position, payloads)
        }

        private fun bindStatus(h: VH, ch: Channel) {
            var st = StatusChecker.status(ch.url)
            if (st == -1) {
                StatusChecker.request(ch) { notifyUrl(ch.url) }
                st = 0
            }
            when (st) {
                1 -> { h.status.text = "✓"; h.status.setBackgroundResource(R.drawable.bg_ok) }
                2 -> { h.status.text = "✕"; h.status.setBackgroundResource(R.drawable.bg_fail) }
                else -> { h.status.text = "…"; h.status.setBackgroundResource(R.drawable.bg_wait) }
            }
        }

        private fun notifyUrl(url: String) {
            main.post {
                val i = items.indexOfFirst { it.url == url }
                if (i >= 0) notifyItemChanged(i, "status")
            }
        }
    }
}
