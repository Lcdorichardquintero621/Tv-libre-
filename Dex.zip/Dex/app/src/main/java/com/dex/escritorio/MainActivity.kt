package com.dex.escritorio

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppItem(val label: String, val pkg: String, val intent: Intent, val icon: Drawable)

class MainActivity : Activity() {

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private lateinit var grid: GridView
    private lateinit var dock: LinearLayout
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var adapter: AppAdapter
    private lateinit var prefs: SharedPreferences

    private var apps: List<AppItem> = emptyList()
    private var overlay: View? = null
    private var windowsMode = true
    private var scale = 1f
    private var cascade = 0
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 15000)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            loadApps()
        }
    }

    // ------------------------------------------------------------ ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        prefs = getSharedPreferences("dex", MODE_PRIVATE)
        windowsMode = prefs.getBoolean("windows", true)
        scale = prefs.getFloat(scaleKey(), 1f)

        root = FrameLayout(this)
        addBackground()
        buildUi()
        setContentView(root)

        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeOverlay()
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (event?.isCtrlPressed == true) {
            if (keyCode == KeyEvent.KEYCODE_PLUS || keyCode == KeyEvent.KEYCODE_EQUALS ||
                keyCode == KeyEvent.KEYCODE_NUMPAD_ADD) {
                setScale((scale + 0.1f).coerceAtMost(2.5f))
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_MINUS || keyCode == KeyEvent.KEYCODE_NUMPAD_SUBTRACT) {
                setScale((scale - 0.1f).coerceAtLeast(0.5f))
                return true
            }
        }
        if (keyCode == KeyEvent.KEYCODE_META_LEFT || keyCode == KeyEvent.KEYCODE_META_RIGHT) {
            openStart()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay != null) closeOverlay()
        // Es la pantalla de inicio: no se cierra.
    }

    // ------------------------------------------------------------ interfaz

    private fun dp(v: Int) = (v * resources.displayMetrics.density * scale).toInt()

    private fun sp(v: Float) = v * scale

    @Suppress("DEPRECATION")
    private fun scaleKey(): String =
        if (windowManager.defaultDisplay.displayId == Display.DEFAULT_DISPLAY) "scale_main" else "scale_ext"

    private fun addBackground() {
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.fondo)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(MP, MP))
    }

    private fun rebuild() {
        closeOverlay()
        root.removeAllViews()
        addBackground()
        buildUi()
        adapter.items = apps
        adapter.notifyDataSetChanged()
        updateStatus()
    }

    private fun setScale(v: Float) {
        scale = v
        prefs.edit().putFloat(scaleKey(), v).apply()
        rebuild()
    }

    private fun scaleDialog() {
        val labels = arrayOf(
            "Muy pequeño (60%)", "Pequeño (80%)", "Normal (100%)",
            "Grande (130%)", "Muy grande (160%)", "Enorme (200%)"
        )
        val values = floatArrayOf(0.6f, 0.8f, 1f, 1.3f, 1.6f, 2f)
        val current = values.indexOfFirst { kotlin.math.abs(it - scale) < 0.05f }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Tamaño del escritorio")
            .setSingleChoiceItems(labels, current) { d, which ->
                setScale(values[which])
                d.dismiss()
            }
            .show()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun buildUi() {
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Barra superior
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(0x66000000)
        }
        val title = TextView(this).apply {
            text = "Mi Escritorio"
            setTextColor(Color.WHITE)
            textSize = sp(14f)
            setTypeface(typeface, Typeface.BOLD)
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = sp(12f)
            setPadding(0, 0, dp(12), 0)
        }
        clock = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = sp(14f)
            setTypeface(typeface, Typeface.BOLD)
        }
        bar.addView(title, LinearLayout.LayoutParams(0, WC, 1f))
        bar.addView(status)
        bar.addView(clock)
        column.addView(bar, LinearLayout.LayoutParams(MP, dp(36)))

        // Escritorio (iconos)
        adapter = AppAdapter(emptyList())
        grid = GridView(this).apply {
            numColumns = GridView.AUTO_FIT
            columnWidth = dp(92)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(10)
            setPadding(dp(16), dp(14), dp(16), dp(8))
            clipToPadding = false
            setSelector(ColorDrawable(0x22FFFFFF))
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> launch(this@MainActivity.adapter.items[pos], windowsMode) }
            setOnItemLongClickListener { _, _, pos, _ -> appMenu(this@MainActivity.adapter.items[pos]); true }
            setOnContextClickListener { desktopMenu(); true }
        }
        column.addView(grid, LinearLayout.LayoutParams(MP, 0, 1f))

        // Dock
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(0x99101826.toInt(), dp(26))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val dockWrap = FrameLayout(this)
        dockWrap.addView(dock, FrameLayout.LayoutParams(WC, WC, Gravity.CENTER_HORIZONTAL))
        column.addView(dockWrap, LinearLayout.LayoutParams(MP, WC).apply { setMargins(0, 0, 0, dp(10)) })

        root.addView(column, FrameLayout.LayoutParams(MP, MP))
        root.setOnContextClickListener { desktopMenu(); true }
        refreshDock()
    }

    inner class AppAdapter(var items: List<AppItem>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val a = items[position]
            val cell = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(6), dp(4), dp(6))
                addView(ImageView(this@MainActivity), LinearLayout.LayoutParams(dp(52), dp(52)))
                addView(TextView(this@MainActivity).apply {
                    setTextColor(Color.WHITE)
                    textSize = sp(12f)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setShadowLayer(4f, 0f, 1f, Color.BLACK)
                }, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(4) })
            }
            (cell.getChildAt(0) as ImageView).setImageDrawable(a.icon)
            (cell.getChildAt(1) as TextView).text = a.label
            return cell
        }
    }

    // ------------------------------------------------------------ dock

    private fun pins(): List<String> {
        val s = prefs.getString("pins", null)
        if (s != null) return s.split(",").filter { it.isNotEmpty() }
        val defaults = listOf(
            "com.android.chrome", "com.google.android.dialer", "com.android.dialer",
            "com.google.android.apps.messaging", "com.google.android.apps.photos",
            "com.sec.android.app.camera", "com.android.camera", "com.android.settings"
        )
        return defaults.filter { d -> apps.any { it.pkg == d } }.take(6)
    }

    private fun setPins(l: List<String>) {
        prefs.edit().putString("pins", l.joinToString(",")).apply()
        refreshDock()
    }

    private fun refreshDock() {
        dock.removeAllViews()
        dock.addView(TextView(this).apply {
            text = "D"
            setTextColor(Color.WHITE)
            textSize = sp(20f)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF7C3AED.toInt(), 0xFF22D3EE.toInt())
            ).apply { cornerRadius = dp(14).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            setOnClickListener { openStart() }
        })
        for (pkg in pins()) {
            val a = apps.firstOrNull { it.pkg == pkg } ?: continue
            dock.addView(ImageView(this).apply {
                setImageDrawable(a.icon)
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
                setOnClickListener { launch(a, windowsMode) }
                setOnLongClickListener { appMenu(a); true }
            })
        }
        dock.addView(TextView(this).apply {
            text = "⚙"
            setTextColor(Color.WHITE)
            textSize = sp(22f)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            setOnClickListener { settingsDialog() }
        })
    }

    // ------------------------------------------------------------ apps

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(
                        ri.loadLabel(pm).toString(),
                        ri.activityInfo.packageName,
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name),
                        ri.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps = list
                adapter.items = list
                adapter.notifyDataSetChanged()
                refreshDock()
            }
        }.start()
    }

    private fun launch(a: AppItem, windowed: Boolean) {
        closeOverlay()
        val i = Intent(a.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (windowed) {
                val dm = resources.displayMetrics
                val w = (dm.widthPixels * 0.7f).toInt()
                val h = (dm.heightPixels * 0.72f).toInt()
                val off = dp(28) * (cascade++ % 6)
                val left = ((dm.widthPixels - w) / 2 - dp(60) + off).coerceAtLeast(0)
                val top = dp(48) + off
                val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(left, top, left + w, top + h))
                startActivity(i, opts.toBundle())
            } else {
                startActivity(i)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir ${a.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun appMenu(a: AppItem) {
        val pinned = pins().contains(a.pkg)
        val options = arrayOf(
            if (pinned) "Quitar del dock" else "Fijar en el dock",
            "Abrir en pantalla completa",
            "Información de la app"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(a.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> setPins(if (pinned) pins() - a.pkg else pins() + a.pkg)
                    1 -> launch(a, false)
                    2 -> safeStart(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                    )
                }
            }
            .show()
    }

    // ------------------------------------------------------------ menú inicio

    private fun openStart() {
        if (overlay != null) { closeOverlay(); return }
        val dm = resources.displayMetrics

        val shade = FrameLayout(this).apply {
            setBackgroundColor(0xAA000000.toInt())
            setOnClickListener { closeOverlay() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(0xEE111827.toInt(), dp(24))
            isClickable = true
        }
        val search = EditText(this).apply {
            hint = "Buscar apps…"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            isSingleLine = true
            background = rounded(0x33FFFFFF, dp(14))
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val results = AppAdapter(apps)
        val g = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(8)
            this.adapter = results
            setOnItemClickListener { _, _, pos, _ -> launch(results.items[pos], windowsMode) }
            setOnItemLongClickListener { _, _, pos, _ -> appMenu(results.items[pos]); true }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim().orEmpty()
                results.items = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                results.notifyDataSetChanged()
            }
        })

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val winChip = chip(if (windowsMode) "🪟 Ventanas: SÍ" else "🪟 Ventanas: NO") { }
        winChip.setOnClickListener {
            windowsMode = !windowsMode
            prefs.edit().putBoolean("windows", windowsMode).apply()
            winChip.text = if (windowsMode) "🪟 Ventanas: SÍ" else "🪟 Ventanas: NO"
        }
        chips.addView(chip("⚙ Dex") { closeOverlay(); settingsDialog() })
        chips.addView(chip("🔍 Tamaño") { closeOverlay(); scaleDialog() })
        chips.addView(chip("📡 Pantalla") { closeOverlay(); safeStart(Intent(Settings.ACTION_CAST_SETTINGS)) })
        chips.addView(winChip)

        card.addView(search, LinearLayout.LayoutParams(MP, WC))
        card.addView(g, LinearLayout.LayoutParams(MP, 0, 1f).apply { topMargin = dp(12) })
        card.addView(chips, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })

        val cw = minOf(dp(560), (dm.widthPixels * 0.92f).toInt())
        val ch = (dm.heightPixels * 0.72f).toInt()
        shade.addView(card, FrameLayout.LayoutParams(cw, ch, Gravity.CENTER))
        root.addView(shade, FrameLayout.LayoutParams(MP, MP))
        overlay = shade
    }

    private fun chip(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = sp(13f)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = rounded(0x33FFFFFF, dp(16))
        layoutParams = LinearLayout.LayoutParams(WC, WC).apply { rightMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun closeOverlay() {
        overlay?.let { root.removeView(it) }
        overlay = null
    }

    // ------------------------------------------------------------ ajustes

    private fun externalDisplays(): List<Display> {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        return dm.displays.filter { it.displayId != Display.DEFAULT_DISPLAY }
    }

    private fun settingsDialog() {
        val n = externalDisplays().size
        val options = arrayOf(
            "Tamaño del escritorio: ${(scale * 100).toInt()}%",
            "Activar ventanas libres (opciones de desarrollador)",
            "Pantalla inalámbrica (Miracast / Cast)",
            "Pantallas y resolución del sistema",
            "Usar Dex como pantalla de inicio"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Dex · pantallas externas: $n")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> scaleDialog()
                    1 -> safeStart(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                    2 -> safeStart(Intent(Settings.ACTION_CAST_SETTINGS))
                    3 -> safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                    4 -> safeStart(Intent(Settings.ACTION_HOME_SETTINGS))
                }
            }
            .show()
    }

    private fun desktopMenu() {
        val options = arrayOf("Menú de inicio", "Ajustes de Dex", "Actualizar apps", "Tamaño del escritorio")
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openStart()
                    1 -> settingsDialog()
                    2 -> loadApps()
                    3 -> scaleDialog()
                }
            }
            .show()
    }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Este teléfono no tiene esa opción", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ barra de estado

    private fun updateStatus() {
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net0 = cm.activeNetwork
        val caps = if (net0 != null) cm.getNetworkCapabilities(net0) else null
        val net = when {
            caps == null -> "Sin red"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Datos"
            else -> "Red"
        }
        val ext = externalDisplays().size
        status.text = (if (ext > 0) "🖥 $ext   " else "") + "📶 $net   🔋 $level%"
    }
}
